//For a square matrix (n x n), print elements where the row index equals the column index. Discuss how this would change if printing the secondary diagonal.
let squareMatrix = [
    ["00", "01", "02"],
    ["10", "11", "12"],
    ["20", "21", "22"],
]

//For a square matrix (n x n), print elements where the row index equals the column index.
console.log(squareMatrix[0][0]);
console.log(squareMatrix[1][1]);
console.log(squareMatrix[2][2]);