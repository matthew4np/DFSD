//Create an arrow function named square that takes a single argument and returns its square

let square = (num) => num * num;

console.log(square(4));