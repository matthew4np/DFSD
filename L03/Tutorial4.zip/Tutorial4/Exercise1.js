//Create a 2D array of integers
let array2D = [
    [1, 2, 3],
    [4, 5, 6],
]

//Access and print the element at the second row and third column.
console.log(array2D[1][2]);

//Change the value of this element
array2D[1][2] = 7;

//and print the entire array.
console.log(array2D);