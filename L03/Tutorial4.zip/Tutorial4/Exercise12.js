//Create an arrow function that takes no arguments and returns the string "Hello, World!".

let helloWorld = () => "Hello World";

console.log(helloWorld());