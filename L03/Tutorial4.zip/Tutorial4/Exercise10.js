//Convert the following traditional function into an arrow function:

// function add(a, b) {
//     return a + b;
//     }

let add = (a, b) => a + b;
console.log(add(1,2));