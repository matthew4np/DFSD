//Create an array named fruits and initialize it with some fruit names.
let arrayFruits = ["Apple","Orange","Pear","Grapes"];

//Add "mango" to the end of the array using the push() method.
arrayFruits.push("Mango");

//Add "strawberry" to the beginning of the array using the unshift() method.
arrayFruits.unshift("Strawberry");

//Print the final array to the console.
console.log(arrayFruits);