//Number
let numberNumbers = 1234;

//String
let stringStrings = "1234";

let sum = numberNumbers + stringStrings;
console.log(sum);