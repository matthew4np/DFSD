//Define a function named calculateArea that takes two parameters: width and height.
function calculateArea(width, height)
{
    //Inside the function, compute the area as width * height
    Area = width * height;

    //return the result;
    return Area;
}

console.log(calculateArea(2,2));