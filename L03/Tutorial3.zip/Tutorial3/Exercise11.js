//Define a function named minutesToSeconds that takes one parameter: minutes.
function minutesToSeconds(minutes)
{
    //Calculate the number of seconds in the given minutes and return that value.
    let numberOfSeconds = minutes * 60;
    return numberOfSeconds;
}

//Test the function with a few sample inputs.
console.log(minutesToSeconds(5));