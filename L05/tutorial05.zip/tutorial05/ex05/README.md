# Class & ID
1. Apply the #heading ID to one appropriate element to affect the result A unique style is applied to the heading area.
2. Apply the class styles to the appropriate elements to affect the result class="?" to your tag elements
      
# Note
1. Notice that block-level child elements inherit the applied style 