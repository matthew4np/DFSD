//Declare two number variables (a and b) and assign them different values.
let a = 5;
let b = 10;

//Swap their values using arithmetic operations.
a = a + b;
b = a - b;
a = a - b;

//Print the new values of a and b.
console.log(`a = ${a}`);
console.log(`b = ${b}`);