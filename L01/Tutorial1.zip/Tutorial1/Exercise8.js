//d dollars
let d = 5;

//c cents
let c = 10 / 100;

//n muffins
let n = 20;

//Assign the variable total the amount (in dollars) Mary must pay.
let total = ((d + c) * n)/100;
console.log(`Total amount is \$${total}`);