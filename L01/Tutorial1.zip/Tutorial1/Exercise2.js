//A variable, named age, with an integer value of 25.
let age = 25;

//A variable, named gst, with a float value of 0.09.
let gst = 0.09;

//A boolean variable, named isRaining, with the value of False.
let isRaining = false;

//A string, named username, with the value of "Samantha Brown".
let username = "Samantha Brown";

console.log(age);
console.log(gst);
console.log(isRaining);
console.log(username);