let x = 4;
let y = 2;

let addition = x + y

let substraction = x - y

let multiplication = x * y

let division = x / y

let modulus = x % y

console.log(addition);
console.log(substraction);
console.log(multiplication);
console.log(division);
console.log(modulus);
