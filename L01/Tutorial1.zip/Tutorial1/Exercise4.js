//Declare two variables to store the numbers (e.g., num1 and num2)
var num1 = 4;
var num2 = 2;

//Perform each arithmetic operation using these variables.
//Print the result of each operation to the console.

//addition
console.log(num1 + num2);

//substraction
console.log(num1 - num2);

//multiplication
console.log(num1 * num2);

//division
console.log(num1 / num2);

//modulus
console.log(num1 % num2);