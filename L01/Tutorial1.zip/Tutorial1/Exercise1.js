
//1. String
let stringP = '53';
console.log(stringP);
console.log(typeof stringP);

//2. Number
let numberP = 53;
console.log(numberP);
console.log(typeof numberP);

//3. BigInt
let bigintP = 53n;
console.log(bigintP);
console.log(typeof bigintP);

//4. Boolean
let booleanP = true;
console.log(booleanP);
console.log(typeof booleanP);

//5. Undefined
let undefinedP;
console.log(undefinedP);
console.log(typeof undefinedP);

//6. Null
let nullP = null;
console.log(nullP);
console.log(typeof nullP);
