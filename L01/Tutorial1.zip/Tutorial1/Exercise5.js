// cost value
let cost = 1.50;

// number of donuts
let numberOfDonuts = 20;

// total cost
let total = cost * numberOfDonuts;

console.log(total)