//They will only go to the beach if the following conditions are met:

let isSunny = false; //The weather is sunny or the weather is cloudy
let isCloudy = true; //The weather is sunny or the weather is cloudy.
let isEveGoing = true; //Eve must be going
let isTuesday = false; //It is not a Tuesday
let isJaniceGoing = false; //Eve’s friend Janice is not going

if ( (!isSunny || isCloudy) && isEveGoing && isTuesday && isJaniceGoing )
{
    console.log("Going to the beach!");
}
else
{
    console.log("Not going to the beach!");
}


