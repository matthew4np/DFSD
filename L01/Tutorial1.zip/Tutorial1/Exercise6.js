// Tax Rate
let taxRate = 2.9 / 100;

// Donald's Income
let income = 450000;

// Total payment
let totalPayment = taxRate * income;

//Display totalPayment with console.log
console.log("$" + totalPayment)