//Declare two variables for length (length) and width (width) of the rectangle.
let length = 5;
let width = 6;

//Calculate the area using the formula
let area = length * width;

//Print the area to the console.
console.log(area);
