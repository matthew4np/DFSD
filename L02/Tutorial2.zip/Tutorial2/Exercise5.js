//Declare Even number
let evenNumber = 2;

//Write a for loop that prints all even numbers from 2 to 20.
for (; evenNumber <= 20; evenNumber += 2)
{
    console.log(evenNumber);
}