//Write a for loop that counts down from 10 to 1
for (let timer = 10; timer >= 0; timer--)
{
    console.log(timer);
}

//and then prints "Liftoff!"
console.log("Liftoff!");

