//Use a for loop to iterate from 1 to 100.
for (let i = 1; i <= 100; i++)
{
    //Print each number in the console.
    console.log(`${i}`);
}