//Initialize an array containing several elements.
let array = [1,true,3,'Hello',5];

//Use a for...of loop to iterate through the array.
for (i = 0; i < array.length; i++)
{
    //Print each element inside the loop.
    console.log(array[i]);
}